/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.student_managment_app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Maurice
 */
public class student {

    private int id;
    private String name;
    private int age;
    private String email;
    private String course;
    public List<student> students = new ArrayList<>();

    public student() {
    }

    public boolean StudentAge(String ageInput) {
        try {
            int ageInputCon = Integer.parseInt(ageInput);
            if (ageInputCon >= 16) {
                return true; // Valid age entered, exit the loop
            } else {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public student SearchStudent(int searchId, List<student> students) {
        for (student student : students) {
            if (student.getId() == searchId) {
                System.out.println("Student found:");
                System.out.println(student); // Display student details
                return student;
            } else {
                System.out.println("Student with ID " + searchId + " not found.");
            }
        }
        return null;
    }

    public student DeleteStudent(int deleteId, List<student> students) {
        for (student student : students) {
            if (student.getId() == deleteId) {
                System.out.println("Student found:");
                System.out.println(student); // Display student details                
                //found = true;
                return student;
            } else {
                return null;
            }
        }
        return null;
    }

    public void StudentReport(List<student> students) {
        System.out.println("Student Report:");

        int studentCount = 1;
        for (student student : students) {
            System.out.println("STUDENT " + studentCount);
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
            System.out.println();
            studentCount++;
        }
    }
    
    public void ExitApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }

    public void SaveStudent(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    public List getStudents() {
        return students;
    }

    @Override
    public String toString() {
        return "STUDENT ID: " + id + "\nSTUDENT NAME: " + name + "\nSTUDENT AGE: " + age
                + "\nSTUDENT EMAIL: " + email + "\nSTUDENT COURSE: " + course;
    }

}
