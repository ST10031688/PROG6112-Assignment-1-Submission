/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.student_managment_app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Maurice
 */
public class Student_managment_app {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String input = scanner.nextLine();
            if (input.equals("1")) {
                displayMenu(scanner);
            } else {
                System.out.println("Exiting the application.");
            }
        }
    }

    private static void displayMenu(Scanner scanner) {
        List<student> students = new ArrayList<>();
        while (true) {
            System.out.println("Menu Options:");
            System.out.println("(1) Capture a new student");
            System.out.println("(2) Search for a student by ID");
            System.out.println("(3) Delete a student");
            System.out.println("(4) Print student report");
            System.out.println("(5) Exit Application");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    CaptureForm(scanner, students);
                    break;
                case 2:
                    SearchForm(scanner, students);
                    break;
                case 3:
                    DeleteForm(scanner, students);
                    break;
                case 4:
                    StudentReport(students);
                    break;
                case 5:
                    ExitApp(scanner);                    
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
            }
        }
    }

    private static void CaptureForm(Scanner scanner, List<student> students) {
        student newStudent = new student();
        System.out.println("Capture a new student:");

        System.out.print("Enter student id: ");
        int id = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        int age;
        while (true) {
            System.out.print("Enter student age (must be 16 or greater): ");
            String ageInput = scanner.nextLine();
            if (newStudent.StudentAge(ageInput)) {
                age = Integer.parseInt(ageInput);
                break;
            } else {
                System.out.println("You have entered an incorrect age!!!. Please re-enter the student age.");
            }
        }

        System.out.print("Enter student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter student course: ");
        String course = scanner.nextLine();
        newStudent.SaveStudent(id, name, age, email, course);

        System.out.println(newStudent.getStudents());
        students.add(newStudent);
        System.out.println("New student captured successfully.");
        System.out.println(students);

    }

    private static void SearchForm(Scanner scanner, List<student> students) {
        student SearchStudent = new student();
        System.out.print("Enter student ID to search: ");
        int searchId;
        while (true) {
            String idInput = scanner.nextLine();
            try {
                searchId = Integer.parseInt(idInput);
                break; // Valid ID entered, exit the loop
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for student ID.");
            }
        }

        SearchStudent.SearchStudent(searchId, students);
    }

    private static void DeleteForm(Scanner scanner, List<student> students) {
        student DeleteStudent = new student();
        System.out.print("Enter student ID to delete: ");
        int deleteId;
        while (true) {
            String idInput = scanner.nextLine();
            try {
                deleteId = Integer.parseInt(idInput);
                break; // Valid ID entered, exit the loop
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for student ID.");
            }
        }
        if (DeleteStudent.DeleteStudent(deleteId, students) == null) {
            System.out.println("Student with ID " + deleteId + " not found.");
        } else {
            System.out.print("Confirm deletion (yes/no): ");
            String confirmation = scanner.nextLine().trim().toLowerCase();

            if (confirmation.equals("yes")) {
                students.remove(DeleteStudent.DeleteStudent(deleteId, students));
                System.out.println("Student deleted.");
            } else {
                System.out.println("Deletion canceled.");
            }
        }
        System.out.println(students);
    }
    
    private static void StudentReport(List<student> students) {
        student PrintStudents = new student();
        PrintStudents.StudentReport(students);
    }
    
    private static void ExitApp(Scanner scanner) {
        student ExitStudentApp = new student();
        scanner.close();
        ExitStudentApp.ExitApplication();
    }
}
