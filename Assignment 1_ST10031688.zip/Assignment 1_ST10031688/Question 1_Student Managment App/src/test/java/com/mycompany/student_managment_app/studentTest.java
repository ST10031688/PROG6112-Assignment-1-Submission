/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.student_managment_app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author Maurice
 */
public class studentTest {
    
    public studentTest() {
    }

    /**
     * Test of StudentAge method, of class student.
     */
    @Test
    public void testStudentAge() {
        student StudentAgeTest = new student();
        String valid_age = "17";
        String invalid_ageN = "15";
        String invalid_ageC = "c";
        
        assertEquals(true, StudentAgeTest.StudentAge(valid_age));
        assertEquals(false, StudentAgeTest.StudentAge(invalid_ageN));
        assertEquals(false, StudentAgeTest.StudentAge(invalid_ageC));
    }

    /**
     * Test of SearchStudent method, of class student.
     */
    @Test
    public void testSearchStudent() {
        /* Test Search Student Found */
        student SearchStudent = new student();
        List<student> students = new ArrayList<>();
        
        int id = 556;
        String name = "John";
        int age = 17;
        String email = "johndoe@mail.com";
        String course = "elen1";        
        
        SearchStudent.SaveStudent(id, name, age, email, course);
        students.add(SearchStudent);
        
        int searchIdTrue = 556;
        
        assertEquals(SearchStudent,SearchStudent.SearchStudent(searchIdTrue, students));        
        
        /* Test Search Student Not Found */
        int searchIdFalse = 555;
        
        assertNotEquals(SearchStudent,SearchStudent.SearchStudent(searchIdFalse, students)); 
    }

    /**
     * Test of DeleteStudent method, of class student.
     */
    @Test
    public void testDeleteStudent() {
        /* Test Delete Student Found */
        student DeleteStudent = new student();
        List<student> students = new ArrayList<>();
        
        int id = 556;
        String name = "John";
        int age = 17;
        String email = "johndoe@mail.com";
        String course = "elen1";        
        
        DeleteStudent.SaveStudent(id, name, age, email, course);
        students.add(DeleteStudent);
        
        int searchIdTrue = 556;
        
        assertEquals(DeleteStudent,DeleteStudent.DeleteStudent(searchIdTrue, students));        
        
        /* Test Search Student Not Found */
        int searchIdFalse = 555;
        
        assertEquals(null,DeleteStudent.DeleteStudent(searchIdFalse, students));
    }

    /**
     * Test of StudentReport method, of class student.
     */
    @Test
    public void testStudentReport() {
    }

    /**
     * Test of ExitApplication method, of class student.
     */
    @Test
    public void testExitApplication() {
    }

    /**
     * Test of SaveStudent method, of class student.
     */
    @Test
    public void testSaveStudent() {
        int id = 1;
        String name = "John";
        int age = 17;
        String email = "johndoe@mail.com";
        String course = "elen1";
        
        student SaveStudent = new student();
        SaveStudent.SaveStudent(id, name, age, email, course);
        
        assertEquals(id, SaveStudent.getId());
        assertEquals(name, SaveStudent.getName());
        assertEquals(age, SaveStudent.getAge());
        assertEquals(email, SaveStudent.getEmail());
        assertEquals(course, SaveStudent.getCourse());
    }

    /**
     * Test of getId method, of class student.
     */
    @Test
    public void testGetId() {
    }

    /**
     * Test of getName method, of class student.
     */
    @Test
    public void testGetName() {
    }

    /**
     * Test of getAge method, of class student.
     */
    @Test
    public void testGetAge() {
    }

    /**
     * Test of getEmail method, of class student.
     */
    @Test
    public void testGetEmail() {
    }

    /**
     * Test of getCourse method, of class student.
     */
    @Test
    public void testGetCourse() {
    }

    /**
     * Test of getStudents method, of class student.
     */
    @Test
    public void testGetStudents() {
    }

    /**
     * Test of toString method, of class student.
     */
    @Test
    public void testToString() {
    }
    
}
