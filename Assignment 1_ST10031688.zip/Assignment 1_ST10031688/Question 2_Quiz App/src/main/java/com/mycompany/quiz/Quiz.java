/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quiz;
import java.util.Scanner;
/**
 *
 * @author Maurice
 */
class MultipleChoiceQuestion extends Question {
    private String[] options;

    public MultipleChoiceQuestion(String questionText, int correctAnswer, String[] options) {
        super(questionText, correctAnswer);
        this.options = options;
    }

    public String[] getOptions() {
        return options;
    }
}

public class Quiz {
    private Question[] questions;
    private int score;

    public Quiz(Question[] questions) {
        this.questions = questions;
        this.score = 0;
    }

    public void startQuiz() {
        Scanner scanner = new Scanner(System.in);

        for (Question question : questions) {
            displayQuestion(question);
            System.out.print("Enter your answer: ");
            int userAnswer = scanner.nextInt();

            if (question.isCorrect(userAnswer)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect. The correct answer was: " + question.getCorrectAnswer());
            }
        }

        System.out.println("Quiz complete!");
        calculateScore();
    }

    public void simulateQuizWithUserInput(int[] userAnswers) {
        if (userAnswers.length != questions.length) {
            throw new IllegalArgumentException("Invalid number of user answers provided.");
        }

        for (int i = 0; i < questions.length; i++) {
            if (questions[i].isCorrect(userAnswers[i])) {
                score++;
            }
        }
    }

    public int getScore() {
        return score;
    }

    private void displayQuestion(Question question) {
        System.out.println(question.getQuestionText());
        if (question instanceof MultipleChoiceQuestion) {
            MultipleChoiceQuestion mcq = (MultipleChoiceQuestion) question;
            String[] options = mcq.getOptions();
            for (int i = 0; i < options.length; i++) {
                System.out.println((i + 1) + ". " + options[i]);
            }
        }
    }

    private void calculateScore() {
        System.out.println("Your Score: " + score + "/" + questions.length);
    }

    public static void main(String[] args) {
        Question[] questions = {
            new MultipleChoiceQuestion("What is 7 x 7?", 2, new String[]{"48", "49", "46"}),
            new MultipleChoiceQuestion("What is the capital of France?", 1, new String[]{"Paris", "Berlin", "Madrid"}),
            new MultipleChoiceQuestion("What is the fastest land animal?", 3, new String[]{"Lion", "Ostrich", "Cheetah"}),
            new MultipleChoiceQuestion("Which country won the 2022 football World Cup?", 2, new String[]{"Russia", "Argentina", "Brazil"}),
            new MultipleChoiceQuestion("Who holds the men's 100m world record?", 1, new String[]{"Usain Bolt", "Noah Lyles", "Lionel Messi"}),
            new MultipleChoiceQuestion("What is the biggest mountain in the world?", 3, new String[]{"K2", "Cho Oyu", "Mount Everest"}),
        };

        Quiz quiz = new Quiz(questions);
        quiz.startQuiz();
    }
}