/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quiz;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Maurice
 */
public class MultipleChoiceQuestionTest {
    
    public MultipleChoiceQuestionTest() {
    }

    /**
     * Test of getOptions method, of class MultipleChoiceQuestion.
     */
    @Test
    public void testGetOptions() {
        System.out.println("getOptions");
        MultipleChoiceQuestion instance = null;
        String[] expResult = null;
        String[] result = instance.getOptions();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
