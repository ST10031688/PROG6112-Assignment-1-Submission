/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quiz;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.Test;

public class QuizTest {
    private Question[] questions;

    @Before
    public void setUp() {
        questions = new Question[]{
            new MultipleChoiceQuestion("What is 7 x 7?", 2, new String[]{"48", "49", "46"}),
            new MultipleChoiceQuestion("What is the capital of France?", 1, new String[]{"Paris", "Berlin", "Madrid"}),
            new MultipleChoiceQuestion("What is the fastest land animal?", 3, new String[]{"Lion", "Ostrich", "Cheetah"}),
            new MultipleChoiceQuestion("Which country won the 2022 football World Cup?", 2, new String[]{"Russia", "Argentina", "Brazil"}),
            new MultipleChoiceQuestion("Who holds the men's 100m world record?", 1, new String[]{"Usain Bolt", "Noah Lyles", "Lionel Messi"}),
            new MultipleChoiceQuestion("What is the biggest mountain in the world?", 3, new String[]{"K2", "Cho Oyu", "Mount Everest"}),
        };
    }

    @Test
    public void testMultipleChoiceQuestion() {
        MultipleChoiceQuestion question = (MultipleChoiceQuestion) questions[0];
        assertEquals("What is 7 x 7?", question.getQuestionText());
        assertEquals(2, question.getCorrectAnswer());
        assertArrayEquals(new String[]{"48", "49", "46"}, question.getOptions());  
    }

   
 
    @Test
    public void testQuizStartQuiz() {
        Quiz quiz = new Quiz(questions);
        // Simulate user input for testing purposes
        quiz.simulateQuizWithUserInput(new int[]{2, 1, 3, 2, 1, 3}); // User answers

        assertEquals(6, quiz.getScore()); // Expected score
    }
    
   @Test
    public void testQuizStartQuizWithAllIncorrectAnswers() {
        Quiz quiz = new Quiz(questions);
        int[] userAnswers = {1, 2, 1, 3, 2, 1};
        quiz.simulateQuizWithUserInput(userAnswers);

        assertEquals(0, quiz.getScore()); // All answers are incorrect
    }

    @Test
    public void testQuizStartQuizWithMixedAnswers() {
        Quiz quiz = new Quiz(questions);
        int[] userAnswers = {2, 1, 3, 1, 2, 3}; // Three correct answers
        quiz.simulateQuizWithUserInput(userAnswers);

        assertEquals(3, quiz.getScore()); // Three answers are correct
    }

    @Test
    public void testQuizStartQuizWithInvalidUserAnswers() {
        Quiz quiz = new Quiz(questions);
        int[] userAnswers = {1, 2, 3}; // Invalid number of answers
        assertThrows(IllegalArgumentException.class, () -> {
            quiz.simulateQuizWithUserInput(userAnswers);
        });
    }
}
